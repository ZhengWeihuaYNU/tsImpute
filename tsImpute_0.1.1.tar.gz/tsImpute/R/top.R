top<- function(expr, n= 200){ #保留每个细胞表达水平排名前100的基因
  cl<- makeCluster(detectCores())
  top_matrix<- matrix(0, nrow(expr), ncol(expr))
  rownames(top_matrix)<- rownames(expr)
  #colnames(top_matrix)<- colnames(expr)
  col_order<- function(i){
    binary_cell<- top_matrix[,i]
    binary_cell[order(expr[,i], decreasing = T)[1:n]]<-1
    binary_cell[expr[,i]==0]<- 0
    return(binary_cell)
  }
  binary_expr<- parLapply(cl, 1:ncol(expr), col_order)
  stopCluster(cl)
  binary_expr<- Reduce(cbind, binary_expr)
  colnames(binary_expr)<- colnames(expr) #由于使用了cbind，需要重新指定列名
  return(binary_expr)
}

#将计数矩阵标准化，行是基因列是细胞
self_preprocess<- function(expr, log= T){
  cell_sum<- colSums(expr)
  data<- sweep(expr, MARGIN = 2, 10^6/cell_sum, FUN = '*')
  if(log== T){
    return(log10(data+1))
  }else{
    return(data)
  }
}
