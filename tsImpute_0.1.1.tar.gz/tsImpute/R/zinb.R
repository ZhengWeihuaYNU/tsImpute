#calculate the response of EM algorithm
response<- function(expr, phi, alpha, lambda){
  p<- alpha/(alpha+lambda)
  b<- phi/(phi+ (1-phi)*(p^alpha)) #退化分布的响应度
  #print(b)
  #注意退化分布只有在为0的表达才有可能有不等于0的响应度
  #若表达不等于0，则退化分布的响应度必为0
  results<- rep(0, length(expr))
  results[expr==0]<- b
  return(results)
}

f<- function(paramt, weights, x){ #更新负二项分布的两个参数,paramt[1]是alpha
  #paramt[2]是lambda
  alpha<- paramt[1]
  lambda<- paramt[2]
  results<- (1-weights)*log(dnbinom(x, alpha, prob= alpha/(alpha+lambda)))
  return(-sum(results))
}

update_nbinom<- function(x, weights, paramt){ #paramt是alpha和lambda组成的向量
  pars<- optim(paramt, f, x= x, weights= weights)
  return(pars$par)
}

#对数似然函数：
loglik<- function(zinb_data, weights, phi, alpha, lambda){
  part1<- (zinb_data==0)*log(phi+(1-phi)*((alpha/(alpha+lambda))^alpha))
  part2<- (zinb_data>0)*(log(1-phi)+ dnbinom(zinb_data, alpha, prob= alpha/(alpha+lambda),
                                             log = T))
  return(sum(part1)+sum(part2))
}

zinb<- function(zinb_data){
  lambda<- mean(zinb_data) #lambda
  if(lambda==0){ #细胞分簇后有可能有某个基因在该簇的所有细胞中全不表达
    #后续可能需要保存这些在某簇中全不表达的基因作为真实0
    estimates<- rep(NA, 4)
    names(estimates)<- c('alpha(size)', 'lambda', 'phi', 'prob')
    return(estimates)
  }
  #  print(lambda)
  alpha<- (lambda^2)/((sd(zinb_data)^2)- lambda)
  if(alpha<=0||alpha==Inf){
    estimates<- rep(NA, 4)
    names(estimates)<- c('alpha(size)', 'lambda', 'phi', 'prob')
    return(estimates)
  }
  #  print(alpha)
  est_sample<- rnbinom(length(zinb_data), alpha, alpha/(alpha+lambda))
  #print(est_sample)
  if(sum(zinb_data==0)>sum(est_sample==0)){
    phi<- (sum(zinb_data==0)-sum(est_sample==0))/sum(zinb_data!=0)
    if(phi>=1){
      phi<- sum(zinb_data==0)/length(zinb_data)
    }
    #上一行有可能导致phi大于1，不合理
  }else{
    phi<- sum(zinb_data==0)/length(zinb_data) #权重
  }
  old_lik<- 0
  t<- 1
  paramt<- c(alpha, lambda)
  estimates<- c(alpha, lambda, phi, alpha/(alpha+lambda))
  names(estimates)<- c('alpha(size)', 'lambda', 'phi', 'prob')
  while(t<=20){
    weights<- response(zinb_data, phi, paramt[1], paramt[2])
    #print(weights)
    paramt<- update_nbinom(zinb_data, weights, paramt)
    alpha<- paramt[1]
    lambda<- paramt[2]
    phi<- mean(weights)
    estimates<- rbind(estimates, c(alpha, lambda, phi, alpha/(alpha+lambda)))
    lik<- loglik(zinb_data, weights, phi, alpha, lambda)
    #print(lik)
    eps<- (lik- old_lik)^2
    if(is.na(lik)){
      print(estimates)
    }
    old_lik<- lik
    if(eps<1){
      break
    }
    t<- t+1
  }
  return(estimates[nrow(estimates),])
}

get_parameters<- function(count){
  options(warn= -1)
  parslist = lapply(1:nrow(count), function(ii) {
    if (ii %% 2000 == 0) {
      gc() #清除垃圾，与python的gc.collect一样
      print(ii)
    }
    xdata = count[ii, ] #xdata是某个基因向量
    paramt = zinb(xdata)
    return(paramt)
  })
  parslist = Reduce(rbind, parslist)
  colnames(parslist) = c('alpha(size)', 'lambda', 'phi', 'prob')
  return(parslist)
}
