jdist<- function(i, expr){
  dist_vec<- rep(0, ncol(expr)) #创建零向量保存距离
  sub_expr<- expr[,i:ncol(expr)] #当前需要计算距离的子表达矩阵
  vec<- expr[,i] #当前细胞向量
  inter<- t(sub_expr)%*%vec #当前细胞与各个细胞的交集大小
  if(i< ncol(expr)){
    sum_expr<- colSums(sub_expr)+sum(vec) #两个集合简单相加
  }else{
    sum_expr<- sum(sub_expr)+ sum(vec)
  }
  union_expr<- sum_expr- inter #并集大小
  jsim<- inter/union_expr #jaccard相似度
  jaccard_dist<- 1- jsim #jaccard距离
  dist_vec[i:length(dist_vec)]<- jaccard_dist
  return(dist_vec)
}

jaccard<- function(expr){ #expr是二元表达矩阵
  #dist_jaccard<- matrix(0, ncol(expr), ncol(expr))
  ncores<- detectCores()
  cl<- makeCluster(ncores)
  dist_mat<- lapply(1:ncol(expr), jdist, expr)
  dist_mat<- Reduce(cbind, dist_mat)
  dist_mat<- dist_mat+ t(dist_mat)
  stopCluster(cl)
  return (dist_mat)
}

j_hcut<- function(x, k){
  x<- as.dist(x)
  return(hcut(x, isdiss = T, k= k))
}


zinb_impute<- function(j, subcount, parlist, dropout_thres, scale_factor){
  gene<- subcount[j,]
  freq<- sum(gene==0)/ncol(subcount)
  dropout_prob<- parlist[j, 'phi']/freq
  dropout_prob<- ifelse(!is.na(dropout_prob), dropout_prob, 0)
  prior<- ifelse((dropout_prob>=dropout_thres)
                 &&(!is.na(parlist[j, 'lambda'])), parlist[j, 'lambda'], 0)
  impute<- (gene==0)*prior*scale_factor*
    ifelse(is.na(dropout_prob), 0, dropout_prob)#初次填充
  gene<- gene+ impute
  return(gene)
}

init_impute<- function(count, cell_cluster, dropout_quantile= 0.5, augment= 1){
  for (i in unique(cell_cluster)){
    parlist<- readRDS(paste0('pars_cluster_',i,'.rds'))
    cell_id<- colnames(count[,cell_cluster==i]) #属于当前簇的细胞名称
    subcount<- count[ ,cell_id] #当前簇的子表达矩阵
    scale_factor<- colSums(subcount)/mean(colSums(subcount))*augment #尺度因子
    dropout_thres<- quantile(parlist[,'phi'], dropout_quantile, na.rm=TRUE)
    ncores<- detectCores()
    cl<- makeCluster(ncores)
    imputed_genes<- parLapply(cl, 1:nrow(subcount), zinb_impute, subcount, parlist,
                              dropout_thres, scale_factor)
    imputed_genes<- Reduce(rbind, imputed_genes)
    #    print(colnames(imputed_genes))
    count[, cell_id]<- imputed_genes
    stopCluster(cl)
  }
  return(count)
}
