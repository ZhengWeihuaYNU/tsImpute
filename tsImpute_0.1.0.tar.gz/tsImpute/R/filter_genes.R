#' @title filter_genes
#'
#' @description This function filters out low expressed genes.
#'
#' @param count A count matrix with rows as genes and columns as cells
#'
#' @param num Genes expressing in less than this number of cells will be filtered.
#'
#' @return An filtered matrix.
#'
#' @export filter_genes

filter_genes<- function(count, num= 5){
  a<- rowSums(count!=0)>= num
  return(count[a, ])
}
