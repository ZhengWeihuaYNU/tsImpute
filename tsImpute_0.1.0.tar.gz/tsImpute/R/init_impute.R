jaccard<- function(expr){ #输入行为细胞列为基因的0-1矩阵
  dist_jaccard<- matrix(0, nrow(expr), nrow(expr))
  for (i in 1:nrow(expr)){
    for (j in 1:i){
      n<- sum((expr[i,]+expr[j,])>0) #并集长度
      dist_jaccard[i,j]<- expr[i,]%*%expr[j,]/n
    }
  }
  for (i in 1:nrow(expr)){
    for (j in i:nrow(expr)){
      dist_jaccard[i,j]<- dist_jaccard[j,i]
    }
  }
  return (1-dist_jaccard)
}

#j_hcut<- function(x, k){
#  return(hcut(dist(x, method= 'Jaccard'), isdiss=T, k=k)) #要用as.dist将矩阵转化为距离矩阵，
#否则会出错 另，这里的dist函数来自proxy包
#}


j_hcut<- function(x, k){
  return(hcut(x,hc_metric = 'binary', k= k))
}


init_impute<- function(count, cell_cluster, dropout_quantile= 0.5, augment= 1){
  for (i in unique(cell_cluster)){
    parlist<- readRDS(paste0('pars_cluster_',i,'.rds'))
    cell_id<- colnames(count[,cell_cluster==i]) #属于当前簇的细胞名称
    subcount<- count[ ,cell_id] #当前簇的子表达矩阵
    scale_factor<- colSums(subcount)/mean(colSums(subcount))*augment #尺度因子
    dropout_thres<- quantile(parlist[,'phi'], dropout_quantile, na.rm=TRUE)
    for(j in 1:nrow(subcount)){
      #某值为dropout的概率根据贝叶斯公式可表示为二项分布的概率(phi)
      #乘以负二项分布不为0的概率再除以该簇中该基因的观测值为0的概率
      freq<- sum(subcount[j,]==0)/ncol(subcount) #贝叶斯公式的分母
      #prob_nonzero<- 1- parlist[j, 'prob']^parlist[j, 'alpha(size)']
      #上一行是负二项分布不为0的概率
      #dropout_prob<- parlist[j, 'phi']*prob_nonzero/freq
      dropout_prob<- parlist[j, 'phi']/freq
      dropout_prob<- ifelse(!is.na(dropout_prob), dropout_prob, 0)
      prior<- ifelse((dropout_prob>=dropout_thres)
                     &&(!is.na(parlist[j, 'lambda'])), parlist[j, 'lambda'], 0)
      #只有当基因对应的dropout值大于阈值才填充
      impute<- (subcount[j, ]==0)*prior*scale_factor*
        ifelse(is.na(dropout_prob), 0, dropout_prob)#初次填充
      subcount[j,]<- subcount[j,]+ impute
    }
    count[, cell_id]<- subcount
  }
  return(count)
}
