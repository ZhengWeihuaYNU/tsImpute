#' @title tsimpute
#'
#' @description This function imputes dropouts of scRNA-seq data in a two step manner.
#'
#' @param count A count matrix with rows as genes and columns as cells
#'
#' @param raw A logical value indicating whether the input matrix contains all genes or just HVGs, tsImpute will select 2000 HVGs if raw= T.
#'
#' @param top_genes The number of highly expressed genes preserved in Jaccard clustering.
#'
#' @param dropout_quantile Genes with dropout probability higher than this quantile will be identified as dropouts.
#'
#' @param augment Augmentation parameter to augment or shrink the imputed value after ZINB imputation.
#'
#' @param max_iter Maximum iteration of IDW imputation.
#'
#' @param eps IDW imputation will stop before maximum iteration if the difference of the expression between two iterations is small than this.
#'
#' @param intensity Weight parameter in the IDW imputation step, a larger value indicates more emphasis on similar cells.
#'
#' @param n_component Number of dimensions preserverd in the umap step.
#'
#' @param min_dist Parameter passed to umap.
#'
#' @param n_neighbor Parameter passed to umap.
#'
#' @param seed Random seed to use.
#'
#' @return An imputed count matrix with rows as genes and columns as cells.
#'
#' @export tsimpute

tsimpute<- function(count, raw= T, top_genes= 200, dropout_quantile= 0.2,
                    max_iter= 10, eps= 0.01, intensity= 2, n_components= 10,
                    min_dist= 0.01, n_neighbors= 5, augment= 1, seed= 1){
  for (pkg in c( 'Seurat', 'factoextra', 'umap')){
    if (!requireNamespace(pkg, quietly = T)){
      stop(paste0('The package ', pkg, ' is not installed'))
    }
  }
  print('Loading Seurat package.' )
  library(Seurat)
  print('Loading factoextra package.')
  library(factoextra)
  print('Loading umap package.')
  library(umap)
  count<- as.matrix(count)
  print(paste0('The sample contains ', ncol(count), ' cells and ',nrow(count),
               ' genes'))
  if (is.null(colnames(count))|is.null(rownames(count))){
    stop('The sample should have both column names and row names.')
  }
  row.names(count)<- gsub('_','-', row.names(count))
  if (raw==T){
    qc_counts<- filter_genes(count, num = round(0.05*ncol(count)))
    dim(qc_counts)
    x.seurat <- CreateSeuratObject(qc_counts)
    x.seurat <- NormalizeData(x.seurat)
    x.seurat <- ScaleData(x.seurat)
    x.seurat <- FindVariableFeatures(x.seurat, verbose = FALSE)
    filter_ID <- x.seurat@assays$RNA@var.features
    filtered<- qc_counts[filter_ID,]
  }else{
    filtered<- count
  }
  print('initial clustering with jaccard distance...')
  aa<- top(filtered, n= top_genes) #这一步处理后可能导致某些基因在所有细胞中的值都为0，要再筛选一次
  #aa同时也可作为filtered矩阵中某基因在某细胞中是否高表达的标志
  gene_mean<- rowMeans(aa)
  #sum(gene_mean==0)
  bi_expr<- aa[gene_mean>0,] #把在所有细胞中均没有高表达的基因删去
  #colSums(bi_expr) #binary expression matrix
  init_cluster<- fviz_nbclust(t(bi_expr), j_hcut, method = 'silhouette',
                              k.max= 20)
  cluster_num<- which.max(init_cluster$data$y) #decide the number of clusters
  hc<- j_hcut(t(bi_expr), cluster_num)
  cell_cluster<- hc$cluster
  print('estimating the distribution parameters of the genes...')
  for(i in unique(cell_cluster)){
    subcount<- filtered[,cell_cluster==i]
    #估计参数放在这里：
    abc<- get_parameters(count = subcount)
    saveRDS(abc, paste0('pars_','cluster_',i,'.rds'))
    #先标记出表达矩阵中为0的位置，若对应的基因dropout概率大于阈值，
    #则该位置是dropout
    #  dropout_thres<- quantile(abc[,'phi'], 0.8, na.rm=TRUE)
  }
  print('initial imputation...')
  dropout_quantile<- dropout_quantile
  xxx<- init_impute(filtered, cell_cluster, dropout_quantile = dropout_quantile, augment = augment) #这个就是初次填充后的结果
  #saveRDS(xxx, 'init_impute.rds')
  if (sum(is.na(xxx))>0){
    stop('Some error leads to NA values, please check your data.')
  }
  print(paste0('zero ratio of the input: ',sum(filtered==0)/length(filtered)))
  print(paste0('zero ratio after initial imputation: ', sum(xxx==0)/length(filtered)))
  #记录下表达矩阵中哪些是经过填充的元素：
  dropout_flag<- matrix(0, nrow(filtered), ncol(filtered))
  rownames(dropout_flag)<- rownames(filtered)
  colnames(dropout_flag)<- colnames(filtered) #给dropout_flag加上细胞名
  dropout_flag[filtered==0&xxx>0]<-1
  dat<- self_preprocess(xxx)
  dim(dat)
  dat_umap<- umap(t(dat), min_dist= min_dist, n_neighbors= n_neighbors,
                  n_components= n_components, random_state= seed)
  mid_cluster<- fviz_nbclust(dat_umap$layout, hcut, method = "silhouette",
                             k.max = 20)
  cluster_num<- which.max(mid_cluster$data$y) #decide the number of clusters
  print(paste0('silhouette coefficient: ', max(mid_cluster$data$y)))
  hc<- hcut(dat_umap$layout, cluster_num)
  impute_cluster<- hc$cluster #记录下每个细胞被分到哪一类
  print('final imputation starts...')
  final_impute<- weight_impute(dat, impute_cluster, dropout_flag, max_iter = max_iter,
                               eps = eps, intensity = intensity)
  library_size<- colSums(xxx) #因为在初次填充后才进行标准化，因此以
  #初次填充后的细胞总表达水平为准去还原counts
  tpm_counts<- (10^final_impute)-1
  impute_counts<- sweep(tpm_counts, MARGIN = 2, library_size/(10^6), FUN = '*')
  output<- count
  output[rownames(impute_counts),]<- impute_counts #这个是与原矩阵相同形状的结果
  print('imputation finished.')
  return (output)
}



