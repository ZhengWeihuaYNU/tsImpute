#dat是待填充矩阵，impute_cluster是细胞的标签，dropout_flag是dropout标志矩阵
weight_impute<- function(dat, impute_cluster, dropout_flag, max_iter= 10, eps= 0.1, intensity= 1){
  #创建一个与表达矩阵相同形状的空矩阵以备填充：
  final_impute<- matrix(0, nrow= nrow(dat), ncol= ncol(dat),
                        dimnames= dimnames(dat))
  #注意给final_impute指定行列名会方便后面的操作
  #对每个簇分别计算距离矩阵以节省时间和空间：
  for (i in unique(impute_cluster)){
    sub_cell<- dat[, impute_cluster==i] #子表达矩阵
    cell_id<- colnames(sub_cell) #记录下这个簇的细胞名
    ddd<- matrix(0, nrow(sub_cell), ncol(sub_cell))
    t<- 1
    while(t<=max_iter){
      dist_matrix<- as.matrix(dist(t(sub_cell))) #距离矩阵
      if(sum(dist_matrix)==0){
        break()
      }
      for (j in 1:nrow(dist_matrix)){
        inv_dist<- 1/(dist_matrix[j,])^intensity #对距离矩阵第j行中的每个值求倒数
        #inv_dist[j]<- 0 #注意距离矩阵对角线为0，倒数为Inf，要将其设置为0
        #还可能有其它情况导致距离为0倒数为Inf，也将其设置为0：
        #inv_dist[inv_dist==Inf]<- 0
        #inv_dist[inv_dist==0]<- sum(inv_dist)/(ncol(dist_matrix)-sum(inv_dist==0)) #将距离为0的权重设置为平均权重
        inv_dist[inv_dist==Inf]<- max(inv_dist[inv_dist!=Inf])
        if(sum(is.na(inv_dist))>0){
          stop('There exist NAs in inv_dist')
        }
        scale_factor<- sum(inv_dist) #将倒数相加
        weights<- inv_dist/scale_factor #得到权重
        #        weights[j]<- max(weights) #将细胞自身的权重设为权重向量中的最大值
        #        weights[weights==0]<- max(weights)
        #        print(max(weights))
        imp<- sub_cell%*%weights #得到簇i中第j个细胞的填充结果
        ddd[,j]<- imp
        #        final_impute[,cell_id[j]]<- imp
      } #一次填充迭代

      diff_expr<- sum(abs(sub_cell- ddd))
      sub_cell<- ddd #更新子表达矩阵
      if(sum(is.na(diff_expr))>0){
        stop('There exist NAs in the matrix')
      }
      if(diff_expr< eps){
        print('converge')
        break
      }
      t<- t+1
      if(t> max_iter){
        print('reach maximum iteration')
      }
    }
    final_impute[,impute_cluster==i]<- sub_cell
    #print(sum(dist_matrix==0)-nrow(dist_matrix))
    #注意计算细胞距离矩阵要转置，确保行是细胞
    #对每个细胞进行填充:

    print(paste('imputation for cluster', i, 'has finished!'))
  }
  final_impute[dropout_flag==0]<- dat[dropout_flag==0]
  return(final_impute)
}
#dropout_flag<- readRDS('dropout_flag.rds')

#将最终插值结果中不是dropout的值还原：
