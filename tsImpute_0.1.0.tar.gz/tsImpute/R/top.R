top<- function(expr, n= 200){ #保留每个细胞表达水平排名前100的基因
  top_matrix<- matrix(0, nrow(expr), ncol(expr))
  rownames(top_matrix)<- rownames(expr)
  colnames(top_matrix)<- colnames(expr)
  for(i in 1:ncol(expr)){
    top_matrix[order(expr[,i], decreasing = T)[1:n],i]<-1
    top_matrix[expr==0]<- 0
  }
  return(top_matrix)
}

#将计数矩阵标准化，行是基因列是细胞
self_preprocess<- function(expr, log= T){
  cell_sum<- colSums(expr)
  data<- sweep(expr, MARGIN = 2, 10^6/cell_sum, FUN = '*')
  if(log== T){
    return(log10(data+1))
  }else{
    return(data)
  }
}
